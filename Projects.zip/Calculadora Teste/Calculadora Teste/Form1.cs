﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_Teste
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float soma;

            //Processamento - operação
            soma = valorNumero1 + valorNumero2;

            //Saída
            MessageBox.Show("a soma é igual a " + soma);


        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float subtracao;

            //Processamento - operação
            subtracao = valorNumero1 - valorNumero2;

            //Saída
            MessageBox.Show("a subtracao é igual a " + subtracao);
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float multiplicar;

            //Processamento - operação
            multiplicar = valorNumero1 * valorNumero2;

            //Saída
            MessageBox.Show("a subtracao é igual a " + multiplicar);
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float dividir;

            //Processamento - operação
            dividir = valorNumero1 / valorNumero2;

            //Saída
            MessageBox.Show("a subtracao é igual a " + dividir);
        }
    }
}
