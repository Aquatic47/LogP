﻿namespace FrmExercícioProva
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVlr1 = new System.Windows.Forms.TextBox();
            this.lblVlr1 = new System.Windows.Forms.Label();
            this.txtVlr3 = new System.Windows.Forms.TextBox();
            this.txtVlr2 = new System.Windows.Forms.TextBox();
            this.lblVlr3 = new System.Windows.Forms.Label();
            this.lblVlr2 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblPorcen1 = new System.Windows.Forms.Label();
            this.lblPorcen2 = new System.Windows.Forms.Label();
            this.lblPorcen3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtVlr1
            // 
            this.txtVlr1.Location = new System.Drawing.Point(61, 83);
            this.txtVlr1.Name = "txtVlr1";
            this.txtVlr1.Size = new System.Drawing.Size(163, 20);
            this.txtVlr1.TabIndex = 0;
            this.txtVlr1.TextChanged += new System.EventHandler(this.txtVlr1_TextChanged);
            // 
            // lblVlr1
            // 
            this.lblVlr1.AutoSize = true;
            this.lblVlr1.Location = new System.Drawing.Point(58, 67);
            this.lblVlr1.Name = "lblVlr1";
            this.lblVlr1.Size = new System.Drawing.Size(40, 13);
            this.lblVlr1.TabIndex = 1;
            this.lblVlr1.Text = "Valor 1";
            // 
            // txtVlr3
            // 
            this.txtVlr3.Location = new System.Drawing.Point(61, 197);
            this.txtVlr3.Name = "txtVlr3";
            this.txtVlr3.Size = new System.Drawing.Size(163, 20);
            this.txtVlr3.TabIndex = 2;
            // 
            // txtVlr2
            // 
            this.txtVlr2.Location = new System.Drawing.Point(61, 143);
            this.txtVlr2.Name = "txtVlr2";
            this.txtVlr2.Size = new System.Drawing.Size(163, 20);
            this.txtVlr2.TabIndex = 3;
            // 
            // lblVlr3
            // 
            this.lblVlr3.AutoSize = true;
            this.lblVlr3.Location = new System.Drawing.Point(58, 181);
            this.lblVlr3.Name = "lblVlr3";
            this.lblVlr3.Size = new System.Drawing.Size(40, 13);
            this.lblVlr3.TabIndex = 4;
            this.lblVlr3.Text = "Valor 3";
            // 
            // lblVlr2
            // 
            this.lblVlr2.AutoSize = true;
            this.lblVlr2.Location = new System.Drawing.Point(58, 127);
            this.lblVlr2.Name = "lblVlr2";
            this.lblVlr2.Size = new System.Drawing.Size(40, 13);
            this.lblVlr2.TabIndex = 5;
            this.lblVlr2.Text = "Valor 2";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(341, 74);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(164, 36);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblPorcen1
            // 
            this.lblPorcen1.AutoSize = true;
            this.lblPorcen1.Location = new System.Drawing.Point(68, 262);
            this.lblPorcen1.Name = "lblPorcen1";
            this.lblPorcen1.Size = new System.Drawing.Size(35, 13);
            this.lblPorcen1.TabIndex = 7;
            this.lblPorcen1.Text = "label1";
            // 
            // lblPorcen2
            // 
            this.lblPorcen2.AutoSize = true;
            this.lblPorcen2.Location = new System.Drawing.Point(68, 291);
            this.lblPorcen2.Name = "lblPorcen2";
            this.lblPorcen2.Size = new System.Drawing.Size(35, 13);
            this.lblPorcen2.TabIndex = 8;
            this.lblPorcen2.Text = "label2";
            // 
            // lblPorcen3
            // 
            this.lblPorcen3.AutoSize = true;
            this.lblPorcen3.Location = new System.Drawing.Point(68, 319);
            this.lblPorcen3.Name = "lblPorcen3";
            this.lblPorcen3.Size = new System.Drawing.Size(35, 13);
            this.lblPorcen3.TabIndex = 9;
            this.lblPorcen3.Text = "label3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblPorcen3);
            this.Controls.Add(this.lblPorcen2);
            this.Controls.Add(this.lblPorcen1);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblVlr2);
            this.Controls.Add(this.lblVlr3);
            this.Controls.Add(this.txtVlr2);
            this.Controls.Add(this.txtVlr3);
            this.Controls.Add(this.lblVlr1);
            this.Controls.Add(this.txtVlr1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVlr1;
        private System.Windows.Forms.Label lblVlr1;
        private System.Windows.Forms.TextBox txtVlr3;
        private System.Windows.Forms.TextBox txtVlr2;
        private System.Windows.Forms.Label lblVlr3;
        private System.Windows.Forms.Label lblVlr2;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblPorcen1;
        private System.Windows.Forms.Label lblPorcen2;
        private System.Windows.Forms.Label lblPorcen3;
    }
}

