﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmExercícioProva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        private void txtVlr1_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Separar valores na tela

            float valor1;
            float valor2;
            float valor3;
            valor1 = float.Parse(txtVlr1.Text);
            valor2 = float.Parse(txtVlr2.Text);
            valor3 = float.Parse(txtVlr3.Text);



            float resultadovalor1 = valor1 + (valor1 / 100) * 10;
            float resultadovalor2 = valor2 + (valor2 / 100) * 10;
            float resultadovalor3 = valor3 + (valor3 / 100) * 10;

            lblPorcen1.Text = "Valor1 aumentado em 10%: " + resultadovalor1;
            lblPorcen2.Text = "Valor2 aumentado em 10%: " + resultadovalor2;
            lblPorcen3.Text = "Valor3 aumentado em 10%: " + resultadovalor3;




            


        }
    }
}
